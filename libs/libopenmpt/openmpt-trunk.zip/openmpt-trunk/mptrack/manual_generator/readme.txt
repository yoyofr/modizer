Prerequisites:
- HTML Help Workshop must be placed in the sub directory "htmlhelp"
- Python 3

Once these prerequisites are fulfilled, simply run wiki.py.
This will download all required files into the "html" sub directory and prepare
all files needed for HTML Help Workshop and spit out a CHM file.