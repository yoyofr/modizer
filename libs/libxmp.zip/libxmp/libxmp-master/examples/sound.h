
int sound_init(int, int);
void sound_play(void *, int);
void sound_deinit(void);

