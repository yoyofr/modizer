// $package user configuration file. Don't replace when updating library.

#pragma once

// Uncomment to have Gb_Apu run at 4x normal clock rate (16777216 Hz), useful in
// a Game Boy Advance emulator.
#define GB_APU_OVERCLOCK 4

// Uncomment if you get errors in the bool section of blargg_common.h
//#define BLARGG_COMPILER_HAS_BOOL 1
